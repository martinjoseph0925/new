#include<iostream>
#include<cstring>
using namespace std;
int main(){
    int i,n;
    string line;
    int temp;
    
    cout<<"enter the string ";
    cin>>line;
    n=line.length();
    for(int i=0;i<n/2;i++){
        temp=line[i];
        line[i]=line[n-1-i];
        line[n-1-i]=temp;

    }
    cout<<line;
    return 0;
}